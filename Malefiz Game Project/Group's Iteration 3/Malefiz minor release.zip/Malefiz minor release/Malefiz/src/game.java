//import javax.swing.UIManager;
import java.util.*;
import java.awt.*;
//import java.awt.event.*;
import javax.swing.*;
@SuppressWarnings("serial")
public class game extends JFrame
//implements ActionListener
{
	
	private LinkedList<player> players;
	private JButton displaySettings;
	private displaySettings displayMode;
	private int numOfPlayers;
	private boolean gameOver;
	private boolean gameMode;
	
	
	public game()
	{
		//set up the game board in constructor
		gameBoard board = new gameBoard();
		board.setUpBoard();
	}
	
	public void chooseDisplay(){
		
	}
	
	public void start() {
		
	}
	
	public void nextTurn() {
		
	}
	
	public boolean winGame() {
		return true;
	}
	
	public void checkPlayers(LinkedList<player> players) {
		
	}
	
	public boolean isGameOver() {
		return true;
	}
	
	public void restart() {
		
	}
}
