
import javax.swing.*;
@SuppressWarnings("serial")
public class Piece extends JButton{

	private String colour;
	private int x,y;
	
	public Piece(int x, int y, String colour) 
	{
		super();
		this.x = x;
		this.y = y;
		this.colour = colour;
		
	}
	public void setColour(String newColour) 
	{
		if (newColour.equals("default"))
		{
			String tileURL = "/resources/default colours/tile.png";
			ImageIcon tile = new ImageIcon(getClass().getResource(tileURL));
			this.setIcon(tile);
			colour = "default";
		}
		if (newColour.equals("red"))
		{
			String redURL = "/resources/default colours/red_tile.png";
			ImageIcon red = new ImageIcon(getClass().getResource(redURL));
			this.setIcon(red);
			colour = "red";
		}
		if (newColour.equals("red_clk"))
		{
			String red_clkURL = "/resources/default colours/red_tile_clk.png";
			ImageIcon red_tile_clk = new ImageIcon(getClass().getResource(red_clkURL));
			this.setIcon(red_tile_clk);
			colour = "red_clk";
		}
		if (newColour.equals("blue"))
		{
			String blueURL = "/resources/default colours/blue_tile.png";
			ImageIcon blue = new ImageIcon(getClass().getResource(blueURL));
			this.setIcon(blue);
			colour = "blue";
		}
		if (newColour.equals("blue_clk"))
		{
			String blue_clkURL = "/resources/default colours/blue_tile_clk.png";
			ImageIcon blue_tile_clk = new ImageIcon(getClass().getResource(blue_clkURL));
			this.setIcon(blue_tile_clk);
			colour = "blue_clk";
		}
		if (newColour.equals("green"))
		{
			String greenURL = "/resources/default colours/green_tile.png";
			ImageIcon green = new ImageIcon(getClass().getResource(greenURL));
			this.setIcon(green);
			colour = "green";
		}
		if (newColour.equals("green_clk"))
		{
			String green_clkURL = "/resources/default colours/green_tile_clk.png";
			ImageIcon green_tile_clk = new ImageIcon(getClass().getResource(green_clkURL));
			this.setIcon(green_tile_clk);
			colour = "green_clk";
		}
		if (newColour.equals("yellow"))
		{
			String yellowURL = "/resources/default colours/yellow_tile.png";
			ImageIcon yellow = new ImageIcon(getClass().getResource(yellowURL));
			this.setIcon(yellow);
			colour = "yellow";
		}
		if (newColour.equals("yellow_clk"))
		{
			String yellow_clkURL = "/resources/default colours/yellow_tile_clk.png";
			ImageIcon yellow_tile_clk = new ImageIcon(getClass().getResource(yellow_clkURL));
			this.setIcon(yellow_tile_clk);
			colour = "yellow_clk";
		}
		if (newColour.equals("barricade"))
		{
			String barricadeURL = "/resources/default colours/barricade.png";
			ImageIcon barricade = new ImageIcon(getClass().getResource(barricadeURL));
			this.setIcon(barricade);
			colour = "barricade";
		}
		if (newColour.equals("barricade_clk"))
		{
			String barricade_clkURL = "/resources/default colours/barricade_tile_clk.png";
			ImageIcon barricade_tile_clk = new ImageIcon(getClass().getResource(barricade_clkURL));
			this.setIcon(barricade_tile_clk);
			colour = "barricade_clk";
		}
		//for colour deficiency
		if (newColour.equals("cdred"))
		{
			
		}
		if (newColour.equals("cdyellow"))
		{
			
		}
		if (newColour.equals("cdblue"))
		{
			
		}
		if (newColour.equals("cdgreen"))
		{
			
		}
	 }
	
		
	
	public String getColour()
	{
		return colour;
	}
	public void setCoord(int newX, int newY)
	{
		x = newX;
		y = newY;
	}
	public int getXCoord()
	{
		return x;
	}
	public int getYCoord()
	{
		return y;
	}
    public boolean isBarricade()
    {
    	return true;
    }
}
