public class Driver {

	public static void main(String[] args) {
		game newGame = new game();

	}

}
