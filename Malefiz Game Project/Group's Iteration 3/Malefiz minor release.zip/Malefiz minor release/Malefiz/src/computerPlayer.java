
public class computerPlayer extends player{

}
