//written by Seyedeh Asal Zarepakziabari Student #: 201920840
//March 19, 2021
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class saveGame {
	private JFrame saveFrame;
	private JButton accept;
	private JButton cancel;
	private JTextField gameName;
	private JLabel nameLabel;
	private JPanel confirmPanel;
	private JFrame confirmFrame;
	private JPanel savePanel;
	private Piece grid[][];
	
	public saveGame(Piece board[][])
	{
		this.grid = board;
		createFrame();
	}

	//create a frame to change the name of the game is being saved
		private void createFrame() {
			
			JPanel textPanel1 = new JPanel();
			savePanel = new JPanel();
			
			saveFrame = new JFrame("Save Game");
			accept = new JButton("Accept");
			cancel = new JButton("Cancel");
			gameName = new JTextField("Game 1", 20);
			
			cancel.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	saveFrame.dispose();
	            }
	        });
			
			accept.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	createConfirmFrame();
	            }
	        });
			

			savePanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
			savePanel.add(accept);
			savePanel.add(cancel);
			textPanel1.add(gameName);
			savePanel.setPreferredSize(new Dimension(300,100));


			saveFrame.getContentPane().setLayout(new BorderLayout());
			saveFrame.getContentPane().add(textPanel1, BorderLayout.CENTER);
			saveFrame.getContentPane().add(savePanel, BorderLayout.SOUTH);
			saveFrame.pack();
			saveFrame.setVisible(true);
			

		}
		
		//create a confirmation window to save the game 
		private void createConfirmFrame() {
			confirmPanel = new JPanel();
	    	nameLabel = new JLabel( gameName.getText());
	    	JLabel confirmation = new JLabel("Are you sure you want to save this game?  ");
	    	JPanel textPanel2 = new JPanel();
			
			confirmFrame = new JFrame("Confirmation");
			JButton confirm = new JButton("Confirm");
			JButton cancel = new JButton("Go Back");
			
			cancel.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	confirmFrame.dispose();
	            }
	        });
			
			//this is where saving the game happens
			confirm.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	createSecondConfirmFrame();
	            	
	            	try {
	            		BufferedWriter writer = new BufferedWriter(new FileWriter("saveGame.txt"));
	            		for (int column = 0; column < 17; column ++)
	            		{
	            			for (int row = 0; row < 17; row ++)
	            			{
	            				Piece tmp = grid[column][row];
	            				if (tmp.isVisible() == true) {
	            					writer.write("" + "Coord: (" + tmp.getXCoord() + "," + tmp.getYCoord() + ") Colour: " + tmp.getColour());
	            					writer.newLine();
	            				}
	            			}
	            		}
	            		writer.close();
					}
					catch(Exception ex) {
						
					}
	            	
	            }
	        });
			
			confirmPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
			confirmPanel.add(confirm);
			confirmPanel.add(cancel);
			textPanel2.add(nameLabel);
			textPanel2.add(confirmation);
			confirmPanel.setPreferredSize(new Dimension(300,100));


			confirmFrame.getContentPane().setLayout(new BorderLayout());
			confirmFrame.getContentPane().add(nameLabel, BorderLayout.CENTER);
			confirmFrame.getContentPane().add(confirmation, BorderLayout.NORTH);
			confirmFrame.getContentPane().add(confirmPanel, BorderLayout.SOUTH);
			confirmFrame.pack();
			confirmFrame.setVisible(true);
		}
		

		
		//create the last confirmation window indicating that the game has been save and an opportunity to resume or exit the game
		private void createSecondConfirmFrame() {
			JPanel panel3 = new JPanel();
	    	JLabel label1 = new JLabel( gameName.getText());
	    	JLabel confirmationLabel = new JLabel("This Game has been saved Successfully!  ");
	    	JPanel textPanel3 = new JPanel();
			
			JFrame frame3 = new JFrame("Confirmation");
			JButton resume = new JButton("Resume Game");
			JButton exit = new JButton("Exit Game");
			
			panel3.setLayout(new FlowLayout(FlowLayout.RIGHT));
			panel3.add(resume);
			panel3.add(exit);
			textPanel3.add(nameLabel);
			textPanel3.add(confirmationLabel);
			panel3.setPreferredSize(new Dimension(300,100));
			
			exit.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	
	            	System.exit(0);
	            	
	            }
	        });
			
			resume.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	frame3.dispose();
	            	confirmFrame.dispose();
	            	saveFrame.dispose();
	            }
	        });
			


			frame3.getContentPane().setLayout(new BorderLayout());
			frame3.getContentPane().add(label1, BorderLayout.CENTER);
			frame3.getContentPane().add(confirmationLabel, BorderLayout.NORTH);
			frame3.getContentPane().add(panel3, BorderLayout.SOUTH);
			frame3.pack();
			frame3.setVisible(true);
			
		}
		
}
