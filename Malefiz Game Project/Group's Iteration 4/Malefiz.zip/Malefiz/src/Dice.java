
import java.util.Random;

/*
 * @author Dinesh Kumar
 */
public class Dice extends javax.swing.JFrame {
	// Variables declaration - do not modify                     
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private int moves;
    private int random;
    // End of variables declaration

    /**
     * Creates new form Dice
     */
    public Dice() {
    	random = getRandomNumber();
    	moves = random;
        initComponents();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.HIDE_ON_CLOSE);

        jLabel1.setText("Dice");
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/default colours/dice/inverted-dice-1.png")));

        jButton1.setText("Roll");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
                jButton1.setText("Close");
                jButton1.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                    	dispose();
                    }
                });   
            }
            
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 12, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>                        

    public int getRandomNumber()
    {
    	Random rd = new Random();
        random=0;
        random=rd.nextInt(6)+1;
        return random;
    }
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        
        switch(random){
            case 1:
                jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/default colours/dice/inverted-dice-1.png")));
                moves = 1;
                break;
            case 2:
            	jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/default colours/dice/inverted-dice-2.png")));
            	moves = 2;
            	break;
            case 3:
                jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/default colours/dice/inverted-dice-3.png")));
                moves = 3;
                break;
            case 4:
                jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/default colours/dice/inverted-dice-4.png")));
                moves = 4;
                break;
            case 5:
                jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/default colours/dice/inverted-dice-5.png")));
                moves = 5;
                break;
            case 6:
                jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/default colours/dice/inverted-dice-6.png")));
                moves = 6;
                break;
        }
    }                                        
    public int getMoves()
    {
    	return moves;
    }
    
}