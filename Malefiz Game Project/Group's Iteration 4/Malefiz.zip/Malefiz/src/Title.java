import javax.swing.*;
import java.awt.*;
// author - Dinesh
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Title{
	private JFrame frame;
	private JButton button1;
	private JButton button2;


    public Title(){
        ImageIcon malefiz_Icon = new ImageIcon(getClass().getResource("/resources/default colours/Malefiz.jpg")); // add the path of the image
        JLabel label = new JLabel(malefiz_Icon);
        label.setSize(550,543);
        button1  = new JButton("New Game");
        button1.setBounds(200,200,190,50);
        button1.setBackground(Color.BLACK);
        button1.setForeground(Color.WHITE);
        button2  = new JButton("Load Game");
        button2.setBounds(200,275,190,50);
        button2.setBackground(Color.BLACK);
        button2.setForeground(Color.WHITE);
        label.add(button1);
        label.add(button2);

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	new game();
            	frame.dispose();
            }
		}
	);
        
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	game Game = new game();
            	gameBoard board = Game.getBoard();
            	board.loadGame();
            	frame.dispose();
            }
		}
	);



        frame = new JFrame("Malefiz Game");
        frame.setLayout(null);
        frame.add(label);
        frame.setResizable(false);
        frame.setSize(550,543);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    
    
    public static void main(String[] args) {
        new Title();


    }

    public JButton getNewGame()
    {
    	return button1;
    }
	
    public JButton getLoadGame()
    {
    	return button2;
    }

}
