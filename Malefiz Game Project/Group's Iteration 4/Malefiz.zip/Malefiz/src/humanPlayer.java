//written by Bethany Pynn
public class humanPlayer extends player{
	
	private String name;
	
	public humanPlayer(String Colour)
	{
		super(Colour);
		this.name = "Default player name";
	}
	
	public void setName(String newName)
	{
		name = newName;
	}
	
	public String getName()
	
	{
		return name;
	}
	
}
