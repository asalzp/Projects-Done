//written by Bethany Pynn
import java.util.ArrayList;

public class player {
    private String colour;
    private int score;
	private Boolean isWinner;
	private Boolean isPlaying;
	private Boolean isPlayerTurn;
	private int moves;
	private Boolean hasRolledDiceFlag;
	private ArrayList<Piece> playerPieces;
	public player(String colour)
	{
		this.colour = colour;
		this.score = 0;
		this.isPlaying = true;
		this.isWinner = false;
		this.isPlayerTurn = false;
		this.hasRolledDiceFlag = false;
		
	}
	
	public String getPlayerColour()
	{
		return colour;
	}
	
	public void setPlayerColour(String newColour)
	{
		colour = newColour;
	}
	
	public void setIsPlaying(Boolean choose)
	{
		isPlaying = choose;
	}
	
	public void setIsPlayerTurn(Boolean choose)
	{
		isPlayerTurn = choose;
	}
	
	public void setIsWinner(Boolean choose)
	{
		isWinner = choose;
	}
	public void setDiceRollFlag(Boolean choose)
	{
		hasRolledDiceFlag = choose;
	}
	public Boolean hasRolledDice()
	{
		return hasRolledDiceFlag;
	}

	@SuppressWarnings("rawtypes")
	public ArrayList getPlayerPieces()
	{
		return playerPieces;
	}
	public void setPlayerPieces(ArrayList pieces)
	{
		playerPieces = pieces;
	}
	
}
