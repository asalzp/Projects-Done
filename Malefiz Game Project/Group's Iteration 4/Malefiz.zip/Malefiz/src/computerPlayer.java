
public class computerPlayer extends player{

	public computerPlayer(String colour) {
		super(colour);
		// TODO Auto-generated constructor stub
	}

}
