//written by Bethany Pynn
//March 29, 2021
//import javax.swing.UIManager;
import java.util.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
//import java.awt.event.*;
import javax.swing.*;
@SuppressWarnings("serial")
public class game extends JFrame implements ActionListener
//implements ActionListener
{
	
	private ArrayList<player> players;
	private JButton displaySettings;
	private displaySettings displayMode;
	private int numOfPlayers;
	private boolean gameOver;
	private boolean gameMode;
	private player player1, player2, player3, player4;
	private player playerTurn;
	private ArrayList<Piece> red, blue, green, yellow;
	private Dice dice;
	private int diceRoll;
	private gameBoard board;
	private Piece lastSelected;
	private Piece beforeLastSelected;
	private Piece barricade;
	private Piece[][] possibleMoves;
	
	public game()
	{
		//set up the game board in constructor
		board = new gameBoard();
		board.setUpBoard();
		players = new ArrayList<player>();
		player1 = new player("red");
		player2 = new player("blue");
		player3 = new player("green");
		player4 = new player("yellow");
		players.add(player1);
		players.add(player2);
		players.add(player3);
		players.add(player4);
		red = new ArrayList<Piece>();
		blue = new ArrayList<Piece>();
		green = new ArrayList<Piece>();
		yellow = new ArrayList<Piece>();
		Piece[][] grid = board.getGrid();
		for (int column = 0; column < 17; column ++)
		{
			for (int row = 0; row < 17; row ++)
			{
				Piece tmp = grid[column][row];
				tmp.addActionListener(this);
				if (tmp.getColour().equals("red"))
				{
					red.add(tmp);
				}
				if (tmp.getColour().equals("blue"))
				{
					blue.add(tmp);
				}
				if (tmp.getColour().equals("green"))
				{
					green.add(tmp);
				}
				if (tmp.getColour().equals("yellow"))
				{
					yellow.add(tmp);
				}
			}
		}
		player1.setPlayerPieces(red);
		player2.setPlayerPieces(blue);
		player3.setPlayerPieces(green);
		player4.setPlayerPieces(yellow);
		player1.setIsPlaying(true);
		player2.setIsPlaying(true);
		player3.setIsPlaying(true);
		player4.setIsPlaying(true);
		player1.setIsPlayerTurn(false);
		player2.setIsPlayerTurn(false);
		player3.setIsPlayerTurn(false);
		player4.setIsPlayerTurn(false);
		player1.setDiceRollFlag(false);
		player2.setDiceRollFlag(false);
		player3.setDiceRollFlag(false);
		player4.setDiceRollFlag(false);
		this.diceRoll = 0;
		this.dice = new Dice();
		lastSelected = new Piece(0, 0, "default");
		beforeLastSelected = new Piece(0, 0, "default");
		barricade = new Piece(0, 0, "default");
		playerTurn = player1;
		gameOver = false;
		possibleMoves = new Piece[4][4];
		start();
	}
	public int getDiceRoll()
	{
		int moves = board.rollDice();
		return moves;
	}
	public void chooseDisplay(){
		
	}
	
	public void move(player Player)
	{
		if (Player.hasRolledDice().equals(false))
		{
			if(Player == player1)
			{
				playerTurn = player1;
			}
			if(Player == player2)
			{
				playerTurn = player2;
			}
			if(Player == player3)
			{
				playerTurn = player3;
			}
			if(Player == player4)
			{
				playerTurn = player4;
			}
		}
		
	}
	
	public void start() {
		//Piece [][] grid = board.getGrid();
		diceRoll = getDiceRoll();
		System.out.println(diceRoll);
		board.setDiceFlag(false);
		if (playerTurn == player1)
		{
			board.setInstructions("Your turn player 1! Roll the dice.");
			board.setPlayer(1);
		}
		if (playerTurn == player2)
		{
			board.setInstructions("Your turn player 2! Roll the dice.");
			board.setPlayer(2);
		}
		if (playerTurn == player3)
		{
			board.setInstructions("Your turn player 3! Roll the dice.");
			board.setPlayer(3);
		}
		if (playerTurn == player4)
		{
			board.setInstructions("Your turn player 4! Roll the dice.");
			board.setPlayer(4);
		}
	}
	
	public player nextTurn(player currentPlayer) {
		if(currentPlayer == (player1))
		{
			return player2;
		}
		if(currentPlayer == (player2))
		{
			return player3;
		}
		if(currentPlayer == (player3))
		{
			return player4;
		}
		if(currentPlayer == (player4))
		{
			return player1;
		}
		return player1;
	}
	
	public void winGame() {
		gameOver = true;
		board.setBlankTile("winning");
		if (playerTurn == player1)
		{
			board.setInstructions("Congratulations player 1! You're the winner!");
		}
		if (playerTurn == player2)
		{
			board.setInstructions("Congratulations player 2! You're the winner!");
		}
		if (playerTurn == player3)
		{
			board.setInstructions("Congratulations player 3! You're the winner!");
		}
		if (playerTurn == player4)
		{
			board.setInstructions("Congratulations player 4! You're the winner!");
		}
	}
	
	
	public boolean isGameOver() {
		return gameOver;
	}
	
	public ArrayList getPlayerList()
	{
		return players;
	}
	
	public void restart() {
		
	}
	
	//author @Heckel on gamedev.stackexchange with modification
	public void possiblePaths(int x, int y, int movesLeft, int commingFrom)
	{
		
	}
	//this method actually moves the pieces!
	public void actionPerformed(ActionEvent e)
	{
		Piece[][] grid = board.getGrid();
		Object o = e.getSource();
		int test1 = ((Piece) o).getXCoord();
		int test2 = ((Piece) o).getYCoord();
		//possiblePaths(test1, test2, getDiceRoll());
		if(board.getDiceFlag() == true && gameOver == false) {
			if(((Piece) o).getColour().equals("default") || ((Piece) o).getColour().equals("winning") || ((Piece) o).getColour().equals("barricade"))
			{
				//if the player clicks on a default square or a barricade, but has not selected a pawn, do nothing
				if(lastSelected.getColour().equals("default") && !barricade.getColour().equals("barricade") )
				{
					return;
				}
				//if they have selected one of their pawns, move it
				else
				{
					int newX = ((Piece) o).getXCoord();
					int newY = ((Piece) o).getYCoord();
					if(grid[newX][newY].getColour().equals("default") && !lastSelected.getColour().equals("barricade") && !barricade.getColour().equals("barricade")) {
						if (playerTurn == player1)
						{
							if (lastSelected.getColour().equals("blue") || lastSelected.getColour().equals("green") || lastSelected.getColour().equals("yellow"))
							{
								return;
							}
							lastSelected.setColour("red");
						}
						else if (playerTurn == player2)
						{
							if (lastSelected.getColour().equals("red") || lastSelected.getColour().equals("green") || lastSelected.getColour().equals("yellow"))
							{
								return;
							}
							lastSelected.setColour("blue");
						}
						else if (playerTurn == player3)
						{
							if (lastSelected.getColour().equals("red") || lastSelected.getColour().equals("blue") || lastSelected.getColour().equals("yellow"))
							{
								return;
							}
							lastSelected.setColour("green");
						}
						else if (playerTurn == player4)
						{
							if (lastSelected.getColour().equals("red") || lastSelected.getColour().equals("green") || lastSelected.getColour().equals("green"))
							{
								return;
							}
							lastSelected.setColour("yellow");
						}
						grid[newX][newY].setColour(lastSelected.getColour());
						lastSelected.setColour("default");
						beforeLastSelected.setColour("default");
						playerTurn = nextTurn(playerTurn);
						board.setBlankTile("default");
						start();
					}
					//If the player lands on a barricade, move it somewhere else
					else if(grid[newX][newY].getColour().equals("barricade"))
					{
						if (playerTurn == player1)
						{
							if (lastSelected.getColour().equals("blue") || lastSelected.getColour().equals("green") || lastSelected.getColour().equals("yellow"))
							{
								return;
							}
							lastSelected.setColour("red");
							board.setInstructions("Player 1, please move the barricade.");
						}
						else if (playerTurn == player2)
						{
							if (lastSelected.getColour().equals("red") || lastSelected.getColour().equals("green") || lastSelected.getColour().equals("yellow"))
							{
								return;
							}
							lastSelected.setColour("blue");
							board.setInstructions("Player 2, please move the barricade.");
						}
						else if (playerTurn == player3)
						{
							if (lastSelected.getColour().equals("red") || lastSelected.getColour().equals("blue") || lastSelected.getColour().equals("yellow"))
							{
								return;
							}
							lastSelected.setColour("green");
							board.setInstructions("Player 3, please move the barricade.");
						}
						else if (playerTurn == player4)
						{
							if (lastSelected.getColour().equals("red") || lastSelected.getColour().equals("green") || lastSelected.getColour().equals("green"))
							{
								return;
							}
							lastSelected.setColour("yellow");
							board.setInstructions("Player 4, please move the barricade.");
						}
						grid[newX][newY].setColour(lastSelected.getColour());
						//barricade.setColour("barricade");
						lastSelected.setColour("default");
						beforeLastSelected.setColour("default");
						board.setBlankTile("barricade");
						barricade.setColour("barricade");
						//start();
				
					}
					//this is how the system knows if the barricade needs to be moved
					else if(barricade.getColour().equals("barricade") && grid[newX][newY].getColour().equals("default"))
					{
						//System.out.println("I work");
						grid[newX][newY].setColour("barricade");
						lastSelected.setColour("default");
						beforeLastSelected.setColour("default");
						board.setBlankTile("default");
						playerTurn = nextTurn(playerTurn);
						barricade.setColour("default");
						start();
					}
					//if the player lands on the winning tile, go to the win game scenario!
					else if(grid[newX][newY].getColour().equals("winning"))
					{
						grid[newX][newY].setColour(lastSelected.getColour());
						lastSelected.setColour("default");
						beforeLastSelected.setColour("default");
						winGame();
					}
						
					
	
				}
			}
				else if(!beforeLastSelected.getColour().equals("red_clk") && !beforeLastSelected.getColour().equals("blue_clk") && !lastSelected.getColour().equals("green_clk") && !lastSelected.getColour().equals("yellow_clk")) {
					
					if (barricade.getColour().equals("barricade"))
					{
						System.out.println("I work");
						lastSelected = (Piece) o ;
						beforeLastSelected = lastSelected;
						//lastSelected.setColour("barricade");
						//beforeLastSelected.setColour("barricade");
					}
					else
					{
						lastSelected = (Piece) o;
						beforeLastSelected = lastSelected;
					if (playerTurn == player1)
					{
						if(!lastSelected.getColour().equals("red"))
						{
							return;
						}
						else
						{
							lastSelected.setColour("red_clk");
							beforeLastSelected.setColour("red_clk");
							board.setBlankTile("red");
						}
					}
					if (playerTurn == player2)
					{
						if(!lastSelected.getColour().equals("blue"))
						{
							return;
						}
						else
						{
							lastSelected.setColour("blue_clk");
							beforeLastSelected.setColour("blue_clk");
							board.setBlankTile("blue");
						}
					}
					if (playerTurn == player3)
					{
						if(!lastSelected.getColour().equals("green"))
						{
							return;
						}
						else
						{
							lastSelected.setColour("green_clk");
							beforeLastSelected.setColour("green_clk");
							board.setBlankTile("green");
						}
					}
					if (playerTurn == player4)
					{
						if(!lastSelected.getColour().equals("yellow"))
						{
							return;
						}
						else
						{
							lastSelected.setColour("yellow_clk");
							beforeLastSelected.setColour("yellow_clk");
							board.setBlankTile("yellow");
						}
					}
				}
				}
			}
		else
		{
			return;
		}
		}
	public gameBoard getBoard()
	{
		return board;
	}
	}

