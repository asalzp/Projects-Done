
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**This class is responsible for providing a user-interface that allows the user to change the game's display settings.
 * 
 * @author Ryan
 *
 */
public class displaySettings extends JFrame
{
	private JPanel topPanel, centerPanel, bottomPanel;
	private JComboBox settingComboBox;
	private String displayOption;
	private String[] settings = { "Default Setting", "Colour Deficiency Friendly"};
	private JButton okButton, returnButton;
	private JLabel displayTitleLabel;	
	
	
	public displaySettings()
	{
        setTitle("Display Settings");
        
        //panels
		   topPanel = new JPanel();
       topPanel.setLayout(new FlowLayout(FlowLayout.CENTER));   
		   centerPanel = new JPanel();
       centerPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 0));   
		   bottomPanel = new JPanel();
       bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 20));
        
        //buttons
        okButton = new JButton("Ok");
        returnButton = new JButton("Close");
        
        //Label
        displayTitleLabel = new JLabel("Display Setting");
        
        //combo box
        settingComboBox = new JComboBox(settings);
        settingComboBox.setSelectedIndex(0);//select the first item as the selected one when the frame becomes visible; would ideally have the user's current display setting
         //listener to perform an action upon the selection of a comboBoxItem. 
        settingComboBox.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent ev) {
            	
            	
            	if(ev.getStateChange()==1)//if the ItemEvent is the currently selected comboBoxItem
            	{
            		chooseDisplayOption(ev.getItem().toString());
            		System.out.println(displayOption);
            	}
//                if(okButton.getText().equals("Ok"))
//                {
//                okButton.setText("Accept Change");
//                returnButton.setText("Discard Change");
////                pack();
//                }
              }
            });
        
        //adding components to panels
        topPanel.add(displayTitleLabel);
        centerPanel.add(settingComboBox);
        
        bottomPanel.add(okButton);
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	dispose();
            }
        });
        bottomPanel.add(returnButton);
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	dispose();
            }
        });
        
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(topPanel, BorderLayout.NORTH);//add top panel to borderlayout
        getContentPane().add(centerPanel, BorderLayout.CENTER);//add center/main panel to borderlayout
        getContentPane().add(bottomPanel, BorderLayout.SOUTH);//add bottom panel to borderlayout
        
        //Frame's final preparation
        setSize(new Dimension(500, 175));
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setResizable(true);
        setLocationRelativeTo(null);
        setVisible(true);
        pack();
	}
	
	/**
	 * Sets the given String as the display setting.
	 * 
	 * @param option
	 */
	private void chooseDisplayOption(String option)
	{
		displayOption = option;
	}
	
	public static void main (String args[])
	{
		new displaySettings();
	}
}


