//written by Bethany Pynn Student #: 201930781 and Seyedeh Asal Zarepakziabari Student #: 201920840
//March 19, 2021

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

@SuppressWarnings("serial")
public class gameBoard extends JFrame implements ActionListener{
	//added some more class variables for aesthetic reasons
	private Piece[][] grid;
	private Icon icon;
	private JPanel topPanel, bottomPanel, sidePanel;
	private JMenu menu;
	private JMenuItem menuItem1, menuItem2;
	private playerSettings playerSettings;
	private displaySettings display_Settings;
	private JButton saveGame;
	private JButton loadGame;
	private JButton resetGame;
	private saveGame save;
	private saveGame load;
	private Dice dice;
	private int diceRoll;
	private JLabel getPlayer;
	private JLabel move;
	private JPanel turnAndPlayer;
	private JLabel instructions;
	private JButton diceButton;
	private boolean diceFlag;
	private JLabel blankTile;
	private ArrayList<Piece[][]> legalMoves;
	public void setUpBoard() {
		JMenuBar menubar = new JMenuBar();
        menu = new JMenu("Settings");
        menubar.add(menu);

        menuItem1 = new JMenuItem("Display Settings");
        menu.add(menuItem1);
        menuItem1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                display_Settings = new displaySettings();
            }
        });


        menuItem2 = new JMenuItem("Player Settings");
        menu.add(menuItem2);
        menuItem2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playerSettings playerSettings = new playerSettings();
                playerSettings.setVisible(true);
            }
        });
		
		//constructor for the top and bottom panels of the GUI
		topPanel = new JPanel();
		topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		Color board = new Color(54, 89, 74);
		bottomPanel = new JPanel();
		bottomPanel.setLayout(new GridLayout(17,17));
		bottomPanel.setBackground(board);
		sidePanel = new JPanel();
		sidePanel.setLayout(new BoxLayout(sidePanel, BoxLayout.Y_AXIS));
		Color brown = new Color(47, 29, 16);
		Color lightGreen = new Color(81, 125, 78);
		sidePanel.setBackground(lightGreen);
		grid = new Piece[17][17];
		diceRoll = 0;
		diceFlag = false;

		icon = new ImageIcon(getClass().getResource("/resources/default colours/tile.png"));

		//this sets up the grid thats 17x17 made of JButtons with tile icons and action listeners
		for (int column = 0; column < 17; column ++)
		{
			for (int row = 0; row < 17; row ++)
			{
				//set the style and size and add action listener
				grid[column][row] = new Piece(column, row, "default");
				grid[column][row].setIcon(icon);
				grid[column][row].setSize(new Dimension(400, 400));
				grid[column][row].setOpaque(true); 
				grid[column][row].setVisible(true);
				grid[column][row].setBorderPainted(false);
				grid[column][row].setEnabled(true);
				grid[column][row].addActionListener(this);

				//add the grid to the bottom panel
				bottomPanel.add(grid [column][row]);
			}
		}

		//making the default player and barricade spaces
		//red
		Piece red1 = new Piece(14, 2, "red");
		Piece red2 = new Piece(15, 1, "red");
		Piece red3 = new Piece(15, 2, "red");
		Piece red4 = new Piece(15, 3, "red");
		Piece red5 = new Piece(16, 2, "red");
		red1 = grid[14][2];
		red1.setColour("red");
		red2 = grid[15][1];
		red2.setColour("red");
		red3 = grid[15][2];
		red3.setColour("red");
		red4 = grid[15][3];
		red4.setColour("red");
		red5 = grid[16][2];
		red5.setColour("red");
		

		//blue
		Piece blue1 = new Piece(14, 6, "blue");
		Piece blue2 = new Piece(15, 5, "blue");
		Piece blue3 = new Piece(15, 6, "blue");
		Piece blue4 = new Piece(15, 7, "blue");
		Piece blue5 = new Piece(16, 6, "blue");
		blue1 = grid[14][6];
		blue1.setColour("blue");
		blue2 = grid[15][5];
		blue2.setColour("blue");
		blue3 = grid[15][6];
		blue3.setColour("blue");
		blue4 = grid[15][7];
		blue4.setColour("blue");
		blue5 = grid[16][6];
		blue5.setColour("blue");

		//green
		Piece green1 = new Piece(14, 10, "green");
		Piece green2 = new Piece(15, 9, "green");
		Piece green3 = new Piece(15, 10, "green");
		Piece green4 = new Piece(15, 11, "green");
		Piece green5 = new Piece(16, 10, "green");
		green1 = grid[14][10];
		green1.setColour("green");
		green2 = grid[15][9];
		green2.setColour("green");
		green3 = grid[15][10];
		green3.setColour("green");
		green4 = grid[15][11];
		green4.setColour("green");
		green5 = grid[16][10];
		green5.setColour("green");

		//yellow
		Piece yellow1 = new Piece(14, 14, "yellow");
		Piece yellow2 = new Piece(15, 13, "yellow");
		Piece yellow3 = new Piece(15, 14, "yellow");
		Piece yellow4 = new Piece(15, 15, "yellow");
		Piece yellow5 = new Piece(16, 14, "yellow");
		yellow1 = grid[14][14];
		yellow1.setColour("yellow");
		yellow2 = grid[15][13];
		yellow2.setColour("yellow");
		yellow3 = grid[15][14];
		yellow3.setColour("yellow");
		yellow4 = grid[15][15];
		yellow4.setColour("yellow");
		yellow5 = grid[16][14];
		yellow5.setColour("yellow");

		//barricades
		Piece b1 = new Piece(11, 0, "barricade");
		Piece b2 = new Piece(11, 4, "barricade");
		Piece b3 = new Piece(11, 8, "barricade");
		Piece b4 = new Piece(11, 12, "barricade");
		Piece b5 = new Piece(11, 16, "barricade");
		Piece b6 = new Piece(7, 6, "barricade");
		Piece b7 = new Piece(7, 10, "barricade");
		Piece b8 = new Piece(5, 8, "barricade");
		Piece b9 = new Piece(4, 8, "barricade");
		Piece b10 = new Piece(3, 8, "barricade");
		Piece b11 = new Piece(1, 8, "barricade");
		b1 = grid[11][0];
		b1.setColour("barricade");
		b2 = grid[11][4];
		b2.setColour("barricade");
		b3 = grid[11][8];
		b3.setColour("barricade");
		b4 = grid[11][12];
		b4.setColour("barricade");
		b5 = grid[11][16];
		b5.setColour("barricade");
		b6 = grid[7][6];
		b6.setColour("barricade");
		b7 = grid[7][10];
		b7.setColour("barricade");
		b8 = grid[5][8];
		b8.setColour("barricade");
		b9 = grid[4][8];
		b9.setColour("barricade");
		b10 = grid[3][8];
		b10.setColour("barricade");
		b11 = grid[1][8];
		b11.setColour("barricade");
		
		

		//winning tile
		grid[0][8].setColour("winning");


		//making buttons we don't need invisible after creating grid, row by row, to create the actual board

		grid[0][0].setVisible(false);
		grid[0][1].setVisible(false);
		grid[0][2].setVisible(false);
		grid[0][3].setVisible(false);
		grid[0][4].setVisible(false);
		grid[0][5].setVisible(false);
		grid[0][6].setVisible(false);
		grid[0][7].setVisible(false);
		grid[0][9].setVisible(false);
		grid[0][10].setVisible(false);
		grid[0][11].setVisible(false);
		grid[0][12].setVisible(false);
		grid[0][13].setVisible(false);
		grid[0][14].setVisible(false);
		grid[0][15].setVisible(false);
		grid[0][16].setVisible(false);

		grid[2][1].setVisible(false);
		grid[2][2].setVisible(false);
		grid[2][3].setVisible(false);
		grid[2][4].setVisible(false);
		grid[2][5].setVisible(false);
		grid[2][6].setVisible(false);
		grid[2][7].setVisible(false);
		grid[2][8].setVisible(false);
		grid[2][9].setVisible(false);
		grid[2][10].setVisible(false);
		grid[2][11].setVisible(false);
		grid[2][12].setVisible(false);
		grid[2][13].setVisible(false);
		grid[2][14].setVisible(false);
		grid[2][15].setVisible(false);

		grid[4][0].setVisible(false);
		grid[4][1].setVisible(false);
		grid[4][2].setVisible(false);
		grid[4][3].setVisible(false);
		grid[4][4].setVisible(false);
		grid[4][5].setVisible(false);
		grid[4][6].setVisible(false);
		grid[4][7].setVisible(false);
		grid[4][9].setVisible(false);
		grid[4][10].setVisible(false);
		grid[4][11].setVisible(false);
		grid[4][12].setVisible(false);
		grid[4][13].setVisible(false);
		grid[4][14].setVisible(false);
		grid[4][15].setVisible(false);
		grid[4][16].setVisible(false);

		grid[5][0].setVisible(false);
		grid[5][1].setVisible(false);
		grid[5][2].setVisible(false);
		grid[5][3].setVisible(false);
		grid[5][4].setVisible(false);
		grid[5][5].setVisible(false);
		grid[5][11].setVisible(false);
		grid[5][12].setVisible(false);
		grid[5][13].setVisible(false);
		grid[5][14].setVisible(false);
		grid[5][15].setVisible(false);
		grid[5][16].setVisible(false);

		grid[6][0].setVisible(false);
		grid[6][1].setVisible(false);
		grid[6][2].setVisible(false);
		grid[6][3].setVisible(false);
		grid[6][4].setVisible(false);
		grid[6][5].setVisible(false);
		grid[6][7].setVisible(false);
		grid[6][8].setVisible(false);
		grid[6][9].setVisible(false);
		grid[6][11].setVisible(false);
		grid[6][12].setVisible(false);
		grid[6][13].setVisible(false);
		grid[6][14].setVisible(false);
		grid[6][15].setVisible(false);
		grid[6][16].setVisible(false);

		grid[7][0].setVisible(false);
		grid[7][1].setVisible(false);
		grid[7][2].setVisible(false);
		grid[7][3].setVisible(false);
		grid[7][13].setVisible(false);
		grid[7][14].setVisible(false);
		grid[7][15].setVisible(false);
		grid[7][16].setVisible(false);

		grid[8][0].setVisible(false);
		grid[8][1].setVisible(false);
		grid[8][2].setVisible(false);
		grid[8][3].setVisible(false);
		grid[8][5].setVisible(false);
		grid[8][6].setVisible(false);
		grid[8][7].setVisible(false);
		grid[8][8].setVisible(false);
		grid[8][9].setVisible(false);
		grid[8][10].setVisible(false);
		grid[8][11].setVisible(false);
		grid[8][13].setVisible(false);
		grid[8][14].setVisible(false);
		grid[8][15].setVisible(false);
		grid[8][16].setVisible(false);

		grid[9][0].setVisible(false);
		grid[9][1].setVisible(false);
		grid[9][15].setVisible(false);
		grid[9][16].setVisible(false);

		grid[10][0].setVisible(false);
		grid[10][1].setVisible(false);
		grid[10][3].setVisible(false);
		grid[10][4].setVisible(false);
		grid[10][5].setVisible(false);
		grid[10][7].setVisible(false);
		grid[10][8].setVisible(false);
		grid[10][9].setVisible(false);
		grid[10][11].setVisible(false);
		grid[10][12].setVisible(false);
		grid[10][13].setVisible(false);
		grid[10][15].setVisible(false);
		grid[10][16].setVisible(false);


		grid[12][1].setVisible(false);
		grid[12][2].setVisible(false);
		grid[12][3].setVisible(false);
		grid[12][5].setVisible(false);
		grid[12][6].setVisible(false);
		grid[12][7].setVisible(false);
		grid[12][9].setVisible(false);
		grid[12][10].setVisible(false);
		grid[12][11].setVisible(false);
		grid[12][13].setVisible(false);
		grid[12][14].setVisible(false);
		grid[12][15].setVisible(false);

		grid[14][0].setVisible(false);
		grid[14][1].setVisible(false);
		grid[14][3].setVisible(false);
		grid[14][4].setVisible(false);
		grid[14][5].setVisible(false);
		grid[14][7].setVisible(false);
		grid[14][8].setVisible(false);
		grid[14][9].setVisible(false);
		grid[14][11].setVisible(false);
		grid[14][12].setVisible(false);
		grid[14][13].setVisible(false);
		grid[14][15].setVisible(false);
		grid[14][16].setVisible(false);

		grid[15][0].setVisible(false);
		grid[15][4].setVisible(false);
		grid[15][8].setVisible(false);
		grid[15][12].setVisible(false);
		grid[15][16].setVisible(false);

		grid[16][0].setVisible(false);
		grid[16][1].setVisible(false);
		grid[16][3].setVisible(false);
		grid[16][4].setVisible(false);
		grid[16][5].setVisible(false);
		grid[16][7].setVisible(false);
		grid[16][8].setVisible(false);
		grid[16][9].setVisible(false);
		grid[16][11].setVisible(false);
		grid[16][12].setVisible(false);
		grid[16][13].setVisible(false);
		grid[16][15].setVisible(false);
		grid[16][16].setVisible(false);  



		//will probably be changed later, but this is the top panel that will have the name of the displays and
		//the settings options probably
		String logoURL = "/resources/default colours/logo.png";
		ImageIcon logo = new ImageIcon(getClass().getResource(logoURL));
		JLabel malefiz = new JLabel();
		malefiz.setIcon(logo);
		instructions = new JLabel("Welcome to Malefiz!");
		instructions.setForeground(Color.white);
		topPanel.add(malefiz);
		topPanel.add(menubar);
		topPanel.add(instructions);
		topPanel.setBackground(brown);
		
		
		
		//this is the side panel!
		
		diceButton = new JButton("Roll dice");
		sidePanel.add(diceButton);
		diceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	dice = new Dice();
        		dice.setVisible(true);
        		diceRoll = dice.getMoves();
        		setDiceFlag(true);
                rollDice(); 
            }
		}
	);
		
		
		//Making a panel to show who's turn it currently is and how many spaces the player can currently move
		turnAndPlayer = new JPanel();
		turnAndPlayer.setLayout(new BoxLayout(turnAndPlayer, BoxLayout.Y_AXIS));
		turnAndPlayer.setPreferredSize(new Dimension(100, 50));
		turnAndPlayer.setBackground(lightGreen);
		getPlayer = new JLabel("Player 1's turn!");
		getPlayer.setForeground(Color.white);
		JLabel space = new JLabel(" ");
		move = new JLabel("Dice roll: " + diceRoll);
		move.setForeground(Color.white);
		blankTile = new JLabel();
		blankTile.setIcon(icon);
		turnAndPlayer.add(getPlayer);
		turnAndPlayer.add(space);
		turnAndPlayer.add(move);
		turnAndPlayer.add(space);
		turnAndPlayer.add(blankTile);
		sidePanel.add(turnAndPlayer);
		//creating a save game button
        saveGame = new JButton("Save Game");
        loadGame = new JButton("Load Game");
        resetGame = new JButton("Restart Game");
      
        saveGame.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		save = new saveGame(grid); 
        	}
        });
      
        loadGame.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		loadGame();
        	}
        });
      
        resetGame.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		resetBoard(); 
        	}
        });
      
        turnAndPlayer.add(Box.createRigidArea(new Dimension(0,450)));
        sidePanel.add(saveGame);
        sidePanel.add(loadGame);
        sidePanel.add(resetGame);
        
		

		//this sets the overall look of the pane by setting the dimensions and the layout,
		//and the packing it all together
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(topPanel, BorderLayout.PAGE_START);
		getContentPane().add(bottomPanel, BorderLayout.CENTER);
		getContentPane().add(sidePanel, BorderLayout.LINE_END);
		bottomPanel.setPreferredSize(new Dimension(500, 500));
		pack();

		//we definitely want to be able to see and close the plane
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);

	}
	
	public int rollDice()
	{
		move.setText("Dice roll: " + diceRoll);
		return diceRoll;
	}
	
	public void setPlayer(int playerNum)
	{
		getPlayer.setText("Player " + playerNum + "'s turn!");
	}
	public void setInstructions(String text)
	{
		instructions.setText(text);
	}
	
	public void setMoveCount(int roll)
	{
		move.setText("Dice roll: " + roll);
	}
	
	public void setDiceFlag(boolean choose)
	{
		diceFlag = choose;
	}
	
	public boolean getDiceFlag()
	{
		return diceFlag;
	}
	public void setBlankTile(String colour)
	{
		ImageIcon newIcon = new ImageIcon();
		if(colour.equals("default"))
		{
			String defaultURL = "/resources/default colours/tile.png";
			ImageIcon default1 = new ImageIcon(getClass().getResource(defaultURL));
			newIcon = default1;
		}
		if(colour.equals("red"))
		{
			String redURL = "/resources/default colours/red_tile.png";
			ImageIcon red = new ImageIcon(getClass().getResource(redURL));
			newIcon = red;
		}
		if(colour.equals("blue"))
		{
			String blueURL = "/resources/default colours/blue_tile.png";
			ImageIcon blue = new ImageIcon(getClass().getResource(blueURL));
			newIcon = blue;
		}
		if(colour.equals("green"))
		{
			String greenURL = "/resources/default colours/green_tile.png";
			ImageIcon green = new ImageIcon(getClass().getResource(greenURL));
			newIcon = green;
		}
		if(colour.equals("yellow"))
		{
			String yellowURL = "/resources/default colours/yellow_tile.png";
			ImageIcon yellow = new ImageIcon(getClass().getResource(yellowURL));
			newIcon = yellow;
		}
		if(colour.equals("winning"))
		{
			String winningURL = "/resources/default colours/winning_tile.png";
			ImageIcon winning = new ImageIcon(getClass().getResource(winningURL));
			newIcon = winning;
		}
		if(colour.equals("barricade"))
		{
			String barricadeURL = "/resources/default colours/barricade.png";
			ImageIcon barricade = new ImageIcon(getClass().getResource(barricadeURL));
			newIcon = barricade;
		}
		blankTile.setIcon(newIcon);
	}
	public JLabel getBlankTile()
	{
		return blankTile;
	}
	
	//this method actually moves the pieces!
	public void actionPerformed(ActionEvent e)
	{
		
	}

	public Piece[][] getGrid()
	{
		return grid;
	}
	
public void resetBoard() {
		
		setInstructions("Welcome to Malefiz!");
		move.setText("Dice roll: " + diceRoll);
		getPlayer.setText("Player 1's turn!");
		setBlankTile("default");
		for (int i = 0; i<17; i++) {
			for(int j = 0; j<17;j++) {
				
				Piece tile = new Piece(i,j,"default");
				tile = grid[i][j];
				
				if (!tile.getColour().equals("default")) {
					tile.setColour("default");
					
				}
			}
			
		}

		//making the default player and barricade spaces
				//red
		Piece red1 = new Piece(14, 2, "red");
		Piece red2 = new Piece(15, 1, "red");
		Piece red3 = new Piece(15, 2, "red");
		Piece red4 = new Piece(15, 3, "red");
		Piece red5 = new Piece(16, 2, "red");
		red1 = grid[14][2];
		red1.setColour("red");
		red1.addActionListener(this);
		
		red2 = grid[15][1];
		red2.setColour("red");
		red2.addActionListener(this);
		
		red3 = grid[15][2];
		red3.setColour("red");
		red3.addActionListener(this);
		
		red4 = grid[15][3];
		red4.setColour("red");
		red4.addActionListener(this);
		
		red5 = grid[16][2];
		red5.setColour("red");
		red5.addActionListener(this);

		//blue
		Piece blue1 = new Piece(14, 6, "blue");
		Piece blue2 = new Piece(15, 5, "blue");
		Piece blue3 = new Piece(15, 6, "blue");
		Piece blue4 = new Piece(15, 7, "blue");
		Piece blue5 = new Piece(16, 6, "blue");
		blue1 = grid[14][6];
		blue1.setColour("blue");
		blue2 = grid[15][5];
		blue2.setColour("blue");
		blue3 = grid[15][6];
		blue3.setColour("blue");
		blue4 = grid[15][7];
		blue4.setColour("blue");
		blue5 = grid[16][6];
		blue5.setColour("blue");

		//green
		Piece green1 = new Piece(14, 10, "green");
		Piece green2 = new Piece(15, 9, "green");
		Piece green3 = new Piece(15, 10, "green");
		Piece green4 = new Piece(15, 11, "green");
		Piece green5 = new Piece(16, 10, "green");
		green1 = grid[14][10];
		green1.setColour("green");
		green2 = grid[15][9];
		green2.setColour("green");
		green3 = grid[15][10];
		green3.setColour("green");
		green4 = grid[15][11];
		green4.setColour("green");
		green5 = grid[16][10];
		green5.setColour("green");

		//yellow
		Piece yellow1 = new Piece(14, 14, "yellow");
		Piece yellow2 = new Piece(15, 13, "yellow");
		Piece yellow3 = new Piece(15, 14, "yellow");
		Piece yellow4 = new Piece(15, 15, "yellow");
		Piece yellow5 = new Piece(16, 14, "yellow");
		yellow1 = grid[14][14];
		yellow1.setColour("yellow");
		yellow2 = grid[15][13];
		yellow2.setColour("yellow");
		yellow3 = grid[15][14];
		yellow3.setColour("yellow");
		yellow4 = grid[15][15];
		yellow4.setColour("yellow");
		yellow5 = grid[16][14];
		yellow5.setColour("yellow");

		//barricades
		Piece b1 = new Piece(11, 0, "barricade");
		Piece b2 = new Piece(11, 4, "barricade");
		Piece b3 = new Piece(11, 8, "barricade");
		Piece b4 = new Piece(11, 12, "barricade");
		Piece b5 = new Piece(11, 16, "barricade");
		Piece b6 = new Piece(7, 6, "barricade");
		Piece b7 = new Piece(7, 10, "barricade");
		Piece b8 = new Piece(5, 8, "barricade");
		Piece b9 = new Piece(4, 8, "barricade");
		Piece b10 = new Piece(3, 8, "barricade");
		Piece b11 = new Piece(1, 8, "barricade");
		b1 = grid[11][0];
		b1.setColour("barricade");
		b2 = grid[11][4];
		b2.setColour("barricade");
		b3 = grid[11][8];
		b3.setColour("barricade");
		b4 = grid[11][12];
		b4.setColour("barricade");
		b5 = grid[11][16];
		b5.setColour("barricade");
		b6 = grid[7][6];
		b6.setColour("barricade");
		b7 = grid[7][10];
		b7.setColour("barricade");
		b8 = grid[5][8];
		b8.setColour("barricade");
		b9 = grid[4][8];
		b9.setColour("barricade");
		b10 = grid[3][8];
		b10.setColour("barricade");
		b11 = grid[1][8];
		b11.setColour("barricade");
		//winning tile
		String winningURL = "/resources/default colours/winning_tile.png";
		ImageIcon winning = new ImageIcon(getClass().getResource(winningURL));
		grid[0][8].setIcon(winning);


		//making buttons we don't need invisible after creating grid, row by row, to create the actual board

		grid[0][0].setVisible(false);
		grid[0][1].setVisible(false);
		grid[0][2].setVisible(false);
		grid[0][3].setVisible(false);
		grid[0][4].setVisible(false);
		grid[0][5].setVisible(false);
		grid[0][6].setVisible(false);
		grid[0][7].setVisible(false);
		grid[0][9].setVisible(false);
		grid[0][10].setVisible(false);
		grid[0][11].setVisible(false);
		grid[0][12].setVisible(false);
		grid[0][13].setVisible(false);
		grid[0][14].setVisible(false);
		grid[0][15].setVisible(false);
		grid[0][16].setVisible(false);

		grid[2][1].setVisible(false);
		grid[2][2].setVisible(false);
		grid[2][3].setVisible(false);
		grid[2][4].setVisible(false);
		grid[2][5].setVisible(false);
		grid[2][6].setVisible(false);
		grid[2][7].setVisible(false);
		grid[2][8].setVisible(false);
		grid[2][9].setVisible(false);
		grid[2][10].setVisible(false);
		grid[2][11].setVisible(false);
		grid[2][12].setVisible(false);
		grid[2][13].setVisible(false);
		grid[2][14].setVisible(false);
		grid[2][15].setVisible(false);

		grid[4][0].setVisible(false);
		grid[4][1].setVisible(false);
		grid[4][2].setVisible(false);
		grid[4][3].setVisible(false);
		grid[4][4].setVisible(false);
		grid[4][5].setVisible(false);
		grid[4][6].setVisible(false);
		grid[4][7].setVisible(false);
		grid[4][9].setVisible(false);
		grid[4][10].setVisible(false);
		grid[4][11].setVisible(false);
		grid[4][12].setVisible(false);
		grid[4][13].setVisible(false);
		grid[4][14].setVisible(false);
		grid[4][15].setVisible(false);
		grid[4][16].setVisible(false);

		grid[5][0].setVisible(false);
		grid[5][1].setVisible(false);
		grid[5][2].setVisible(false);
		grid[5][3].setVisible(false);
		grid[5][4].setVisible(false);
		grid[5][5].setVisible(false);
		grid[5][11].setVisible(false);
		grid[5][12].setVisible(false);
		grid[5][13].setVisible(false);
		grid[5][14].setVisible(false);
		grid[5][15].setVisible(false);
		grid[5][16].setVisible(false);

		grid[6][0].setVisible(false);
		grid[6][1].setVisible(false);
		grid[6][2].setVisible(false);
		grid[6][3].setVisible(false);
		grid[6][4].setVisible(false);
		grid[6][5].setVisible(false);
		grid[6][7].setVisible(false);
		grid[6][8].setVisible(false);
		grid[6][9].setVisible(false);
		grid[6][11].setVisible(false);
		grid[6][12].setVisible(false);
		grid[6][13].setVisible(false);
		grid[6][14].setVisible(false);
		grid[6][15].setVisible(false);
		grid[6][16].setVisible(false);

		grid[7][0].setVisible(false);
		grid[7][1].setVisible(false);
		grid[7][2].setVisible(false);
		grid[7][3].setVisible(false);
		grid[7][13].setVisible(false);
		grid[7][14].setVisible(false);
		grid[7][15].setVisible(false);
		grid[7][16].setVisible(false);

		grid[8][0].setVisible(false);
		grid[8][1].setVisible(false);
		grid[8][2].setVisible(false);
		grid[8][3].setVisible(false);
		grid[8][5].setVisible(false);
		grid[8][6].setVisible(false);
		grid[8][7].setVisible(false);
		grid[8][8].setVisible(false);
		grid[8][9].setVisible(false);
		grid[8][10].setVisible(false);
		grid[8][11].setVisible(false);
		grid[8][13].setVisible(false);
		grid[8][14].setVisible(false);
		grid[8][15].setVisible(false);
		grid[8][16].setVisible(false);

		grid[9][0].setVisible(false);
		grid[9][1].setVisible(false);
		grid[9][15].setVisible(false);
		grid[9][16].setVisible(false);

		grid[10][0].setVisible(false);
		grid[10][1].setVisible(false);
		grid[10][3].setVisible(false);
		grid[10][4].setVisible(false);
		grid[10][5].setVisible(false);
		grid[10][7].setVisible(false);
		grid[10][8].setVisible(false);
		grid[10][9].setVisible(false);
		grid[10][11].setVisible(false);
		grid[10][12].setVisible(false);
		grid[10][13].setVisible(false);
		grid[10][15].setVisible(false);
		grid[10][16].setVisible(false);


		grid[12][1].setVisible(false);
		grid[12][2].setVisible(false);
		grid[12][3].setVisible(false);
		grid[12][5].setVisible(false);
		grid[12][6].setVisible(false);
		grid[12][7].setVisible(false);
		grid[12][9].setVisible(false);
		grid[12][10].setVisible(false);
		grid[12][11].setVisible(false);
		grid[12][13].setVisible(false);
		grid[12][14].setVisible(false);
		grid[12][15].setVisible(false);

		grid[14][0].setVisible(false);
		grid[14][1].setVisible(false);
		grid[14][3].setVisible(false);
		grid[14][4].setVisible(false);
		grid[14][5].setVisible(false);
		grid[14][7].setVisible(false);
		grid[14][8].setVisible(false);
		grid[14][9].setVisible(false);
		grid[14][11].setVisible(false);
		grid[14][12].setVisible(false);
		grid[14][13].setVisible(false);
		grid[14][15].setVisible(false);
		grid[14][16].setVisible(false);

		grid[15][0].setVisible(false);
		grid[15][4].setVisible(false);
		grid[15][8].setVisible(false);
		grid[15][12].setVisible(false);
		grid[15][16].setVisible(false);

		grid[16][0].setVisible(false);
		grid[16][1].setVisible(false);
		grid[16][3].setVisible(false);
		grid[16][4].setVisible(false);
		grid[16][5].setVisible(false);
		grid[16][7].setVisible(false);
		grid[16][8].setVisible(false);
		grid[16][9].setVisible(false);
		grid[16][11].setVisible(false);
		grid[16][12].setVisible(false);
		grid[16][13].setVisible(false);
		grid[16][15].setVisible(false);
		grid[16][16].setVisible(false);
		
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(topPanel, BorderLayout.PAGE_START);
		getContentPane().add(bottomPanel, BorderLayout.CENTER);
		getContentPane().add(sidePanel, BorderLayout.LINE_END);
		bottomPanel.setPreferredSize(new Dimension(500, 500));
		pack();
	}
	

	

	 /*
	  * @author Ryan_DS(stackoverflow)
	  */
	
	public int[] parseXYCoord(String s) {
	    String master=s;
	    if(s.contains(",")){
	        master=master.replace("(","").replace(")","");
	        master=master.replace(","," ");
	    }else if(master.matches("^[a-z]((\\s[0-8])|[0-8])$")){
	        int charValue=master.charAt(0)-'a'+1;
	        master=charValue+" "+master.charAt(master.contains(" ")?2:1);


	    }
	    return parseMaster(master);
	}

	private int[] parseMaster(String master) {

	    String[] splitMaster=master.split(" ");
	    return new int[]{Integer.parseInt(splitMaster[0]),Integer.parseInt(splitMaster[1])};

	}
		public void loadGame() {
			
			 int coordinate;
			 String colour;
			 
			 
			 
			 /*
			  * @author w3schools.com with modification
			  */
			 try {
			      File myObj = new File("saveGame.txt");
			      Scanner myReader = new Scanner(myObj);
			      while (myReader.hasNextLine()) {
			    	  String line = myReader.nextLine();
			    	  String[] data = line.split(" ");
			    	  
			        
			        parseXYCoord(data[1]);
			        
			        int xcoord = parseXYCoord(data[1])[0];
			        int ycoord = parseXYCoord(data[1])[1];
			       
			        
			        if (data[3].equals("red")) {
			        	for(int i = 0; i<5; i++) {
			        		Piece red = new Piece(xcoord, ycoord, "red");
			        		red = grid[xcoord][ycoord];
			        		red.setColour("red");
			        		red.addActionListener(this);
			        		
			        		
			        		
							
			        	}
			        }
			        	
			        	else if (data[3].equals("blue")) {
				        for(int i = 0; i<5; i++) {
				        	Piece blue = new Piece(xcoord, ycoord, "blue");
				        	blue = grid[xcoord][ycoord];
				        	blue.setColour("blue");
				        	blue.addActionListener(this);
				        	}
			        	}
				        	
				        else if (data[3].equals("green")) {
					    for(int i = 0; i<5; i++) {
					        Piece green = new Piece(xcoord, ycoord, "green");
					        green = grid[xcoord][ycoord];
					        green.setColour("green");
					        green.addActionListener(this);
					        	}
				        }
			        
					    else if (data[3].equals("yellow")) {
						for(int i = 0; i<5; i++) {
						    Piece yellow = new Piece(xcoord, ycoord, "yellow");
						    yellow = grid[xcoord][ycoord];
						    yellow.setColour("yellow");
						    yellow.addActionListener(this);
						        	}
					    }
			        
					    else if (data[3].equals("default")) {
							for(int i = 0; i < 101; i++) {
							    Piece tile = new Piece(xcoord, ycoord, "default");
							    tile = grid[xcoord][ycoord];
							    tile.setColour("default");
							    tile.addActionListener(this);
							        	}
						    }
					    else if (data[3].equals("barricade")) {
					    	for(int i = 0; i < 11; i++) {
					    	Piece barricade = new Piece(xcoord, ycoord, "barricade");
					    	barricade = grid[xcoord][ycoord];
					    	barricade.setColour("barricade");
					    	barricade.addActionListener(this);
					    	
					    }
					    }
			        
			        }
			        
			      		
			      
			      myReader.close();
			    } catch (FileNotFoundException e) {
			      System.out.println("An error occurred.");
			      e.printStackTrace();
			    }
			
		

			 
			
			 
	//barricades
	Piece b1 = new Piece(11, 0, "barricade");
	Piece b2 = new Piece(11, 4, "barricade");
	Piece b3 = new Piece(11, 8, "barricade");
	Piece b4 = new Piece(11, 12, "barricade");
	Piece b5 = new Piece(11, 16, "barricade");
	Piece b6 = new Piece(7, 6, "barricade");
	Piece b7 = new Piece(7, 10, "barricade");
	Piece b8 = new Piece(5, 8, "barricade");
	Piece b9 = new Piece(4, 8, "barricade");
	Piece b10 = new Piece(3, 8, "barricade");
	Piece b11 = new Piece(1, 8, "barricade");
	b1 = grid[11][0];
	b1.setColour("barricade");
	b2 = grid[11][4];
	b2.setColour("barricade");
	b3 = grid[11][8];
	b3.setColour("barricade");
	b4 = grid[11][12];
	b4.setColour("barricade");
	b5 = grid[11][16];
	b5.setColour("barricade");
	b6 = grid[7][6];
	b6.setColour("barricade");
	b7 = grid[7][10];
	b7.setColour("barricade");
	b8 = grid[5][8];
	b8.setColour("barricade");
	b9 = grid[4][8];
	b9.setColour("barricade");
	b10 = grid[3][8];
	b10.setColour("barricade");
	b11 = grid[1][8];
	b11.setColour("barricade");
	//winning tile
	String winningURL = "/resources/default colours/winning_tile.png";
	ImageIcon winning = new ImageIcon(getClass().getResource(winningURL));
	grid[0][8].setIcon(winning);


	//making buttons we don't need invisible after creating grid, row by row, to create the actual board

	grid[0][0].setVisible(false);
	grid[0][1].setVisible(false);
	grid[0][2].setVisible(false);
	grid[0][3].setVisible(false);
	grid[0][4].setVisible(false);
	grid[0][5].setVisible(false);
	grid[0][6].setVisible(false);
	grid[0][7].setVisible(false);
	grid[0][9].setVisible(false);
	grid[0][10].setVisible(false);
	grid[0][11].setVisible(false);
	grid[0][12].setVisible(false);
	grid[0][13].setVisible(false);
	grid[0][14].setVisible(false);
	grid[0][15].setVisible(false);
	grid[0][16].setVisible(false);

	grid[2][1].setVisible(false);
	grid[2][2].setVisible(false);
	grid[2][3].setVisible(false);
	grid[2][4].setVisible(false);
	grid[2][5].setVisible(false);
	grid[2][6].setVisible(false);
	grid[2][7].setVisible(false);
	grid[2][8].setVisible(false);
	grid[2][9].setVisible(false);
	grid[2][10].setVisible(false);
	grid[2][11].setVisible(false);
	grid[2][12].setVisible(false);
	grid[2][13].setVisible(false);
	grid[2][14].setVisible(false);
	grid[2][15].setVisible(false);

	grid[4][0].setVisible(false);
	grid[4][1].setVisible(false);
	grid[4][2].setVisible(false);
	grid[4][3].setVisible(false);
	grid[4][4].setVisible(false);
	grid[4][5].setVisible(false);
	grid[4][6].setVisible(false);
	grid[4][7].setVisible(false);
	grid[4][9].setVisible(false);
	grid[4][10].setVisible(false);
	grid[4][11].setVisible(false);
	grid[4][12].setVisible(false);
	grid[4][13].setVisible(false);
	grid[4][14].setVisible(false);
	grid[4][15].setVisible(false);
	grid[4][16].setVisible(false);

	grid[5][0].setVisible(false);
	grid[5][1].setVisible(false);
	grid[5][2].setVisible(false);
	grid[5][3].setVisible(false);
	grid[5][4].setVisible(false);
	grid[5][5].setVisible(false);
	grid[5][11].setVisible(false);
	grid[5][12].setVisible(false);
	grid[5][13].setVisible(false);
	grid[5][14].setVisible(false);
	grid[5][15].setVisible(false);
	grid[5][16].setVisible(false);

	grid[6][0].setVisible(false);
	grid[6][1].setVisible(false);
	grid[6][2].setVisible(false);
	grid[6][3].setVisible(false);
	grid[6][4].setVisible(false);
	grid[6][5].setVisible(false);
	grid[6][7].setVisible(false);
	grid[6][8].setVisible(false);
	grid[6][9].setVisible(false);
	grid[6][11].setVisible(false);
	grid[6][12].setVisible(false);
	grid[6][13].setVisible(false);
	grid[6][14].setVisible(false);
	grid[6][15].setVisible(false);
	grid[6][16].setVisible(false);

	grid[7][0].setVisible(false);
	grid[7][1].setVisible(false);
	grid[7][2].setVisible(false);
	grid[7][3].setVisible(false);
	grid[7][13].setVisible(false);
	grid[7][14].setVisible(false);
	grid[7][15].setVisible(false);
	grid[7][16].setVisible(false);

	grid[8][0].setVisible(false);
	grid[8][1].setVisible(false);
	grid[8][2].setVisible(false);
	grid[8][3].setVisible(false);
	grid[8][5].setVisible(false);
	grid[8][6].setVisible(false);
	grid[8][7].setVisible(false);
	grid[8][8].setVisible(false);
	grid[8][9].setVisible(false);
	grid[8][10].setVisible(false);
	grid[8][11].setVisible(false);
	grid[8][13].setVisible(false);
	grid[8][14].setVisible(false);
	grid[8][15].setVisible(false);
	grid[8][16].setVisible(false);

	grid[9][0].setVisible(false);
	grid[9][1].setVisible(false);
	grid[9][15].setVisible(false);
	grid[9][16].setVisible(false);

	grid[10][0].setVisible(false);
	grid[10][1].setVisible(false);
	grid[10][3].setVisible(false);
	grid[10][4].setVisible(false);
	grid[10][5].setVisible(false);
	grid[10][7].setVisible(false);
	grid[10][8].setVisible(false);
	grid[10][9].setVisible(false);
	grid[10][11].setVisible(false);
	grid[10][12].setVisible(false);
	grid[10][13].setVisible(false);
	grid[10][15].setVisible(false);
	grid[10][16].setVisible(false);


	grid[12][1].setVisible(false);
	grid[12][2].setVisible(false);
	grid[12][3].setVisible(false);
	grid[12][5].setVisible(false);
	grid[12][6].setVisible(false);
	grid[12][7].setVisible(false);
	grid[12][9].setVisible(false);
	grid[12][10].setVisible(false);
	grid[12][11].setVisible(false);
	grid[12][13].setVisible(false);
	grid[12][14].setVisible(false);
	grid[12][15].setVisible(false);

	grid[14][0].setVisible(false);
	grid[14][1].setVisible(false);
	grid[14][3].setVisible(false);
	grid[14][4].setVisible(false);
	grid[14][5].setVisible(false);
	grid[14][7].setVisible(false);
	grid[14][8].setVisible(false);
	grid[14][9].setVisible(false);
	grid[14][11].setVisible(false);
	grid[14][12].setVisible(false);
	grid[14][13].setVisible(false);
	grid[14][15].setVisible(false);
	grid[14][16].setVisible(false);

	grid[15][0].setVisible(false);
	grid[15][4].setVisible(false);
	grid[15][8].setVisible(false);
	grid[15][12].setVisible(false);
	grid[15][16].setVisible(false);

	grid[16][0].setVisible(false);
	grid[16][1].setVisible(false);
	grid[16][3].setVisible(false);
	grid[16][4].setVisible(false);
	grid[16][5].setVisible(false);
	grid[16][7].setVisible(false);
	grid[16][8].setVisible(false);
	grid[16][9].setVisible(false);
	grid[16][11].setVisible(false);
	grid[16][12].setVisible(false);
	grid[16][13].setVisible(false);
	grid[16][15].setVisible(false);
	grid[16][16].setVisible(false);
			
	
	
			
	getContentPane().setLayout(new BorderLayout());
	getContentPane().add(topPanel, BorderLayout.PAGE_START);
	getContentPane().add(bottomPanel, BorderLayout.CENTER);
	getContentPane().add(sidePanel, BorderLayout.LINE_END);
	bottomPanel.setPreferredSize(new Dimension(500, 500));
	pack();
			
		
		

	}
}