
public class humanPlayer extends player{

}
