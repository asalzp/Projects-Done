//written by Bethany Pynn
//Student #: 201930781
//March 5, 2021

import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;

@SuppressWarnings("serial")
public class gameBoard extends JFrame{
	//added some more class variables for aesthetic reasons
	LinkedList<Piece> pieces;
	private JButton[][] grid;
	private Icon icon;
	private JPanel topPanel, bottomPanel;
	private JMenu menu;
	private JMenuItem menuItem1, menuItem2;
	private playerSettings playerSettings;
	private displaySettings display_Settings;
	
	
	public void setUpBoard() {
		JMenuBar menubar = new JMenuBar();
        menu = new JMenu("Settings");
        menubar.add(menu);

        menuItem1 = new JMenuItem("Display Settings");
        menu.add(menuItem1);
        menuItem1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                display_Settings = new displaySettings();
            }
        });


        menuItem2 = new JMenuItem("Player Settings");
        menu.add(menuItem2);
        menuItem2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playerSettings playerSettings = new playerSettings();
                playerSettings.setVisible(true);
            }
        });
		
		//constructor for the top and bottom panels of the GUI
		topPanel = new JPanel();
		topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		Color board = new Color(54, 89, 74);
		bottomPanel = new JPanel();
		bottomPanel.setLayout(new GridLayout(17,17));
		bottomPanel.setBackground(board);
		grid = new JButton[17][17];

		icon = new ImageIcon(getClass().getResource("/resources/tile.png"));

		//this sets up the grid thats 17x17 made of JButtons with tile icons and action listeners
		for (int column = 0; column < 17; column ++)
		{
			for (int row = 0; row < 17; row ++)
			{
				//set the style and size and add action listener
				grid[column][row] = new JButton();
				grid[column][row].setIcon(icon);
				grid[column][row].setSize(new Dimension(400, 400));
				grid[column][row].setOpaque(true); 
				grid[column][row].setVisible(true);
				grid[column][row].setBorderPainted(false);
				grid[column][row].setEnabled(true);
				//grid[column][row].addActionListener(this);

				//add the grid to the bottom panel
				bottomPanel.add(grid [column][row]);
			}
		}

		//making the default player and barricade spaces
		//red
		String redURL = "/resources/red_tile.png";
		ImageIcon red = new ImageIcon(getClass().getResource(redURL));
		grid[14][2].setIcon(red);
		grid[15][1].setIcon(red);
		grid[15][2].setIcon(red);
		grid[15][3].setIcon(red);
		grid[16][2].setIcon(red);

		//blue
		String blueURL = "/resources/blue_tile.png";
		ImageIcon blue = new ImageIcon(getClass().getResource(blueURL));
		grid[14][6].setIcon(blue);
		grid[15][5].setIcon(blue);
		grid[15][6].setIcon(blue);
		grid[15][7].setIcon(blue);
		grid[16][6].setIcon(blue);

		//green
		String greenURL = "/resources/green_tile.png";
		ImageIcon green = new ImageIcon(getClass().getResource(greenURL));
		grid[14][10].setIcon(green);
		grid[15][9].setIcon(green);
		grid[15][10].setIcon(green);
		grid[15][11].setIcon(green);
		grid[16][10].setIcon(green);

		//yellow
		String yellowURL = "/resources/yellow_tile.png";
		ImageIcon yellow = new ImageIcon(getClass().getResource(yellowURL));
		grid[14][14].setIcon(yellow);
		grid[15][13].setIcon(yellow);
		grid[15][14].setIcon(yellow);
		grid[15][15].setIcon(yellow);
		grid[16][14].setIcon(yellow);

		//barricades
		String barricadeURL = "/resources/barricade.png";
		ImageIcon barricade = new ImageIcon(getClass().getResource(barricadeURL));
		grid[11][0].setIcon(barricade);
		grid[11][4].setIcon(barricade);
		grid[11][8].setIcon(barricade);
		grid[11][12].setIcon(barricade);
		grid[11][16].setIcon(barricade);
		grid[7][6].setIcon(barricade);
		grid[7][10].setIcon(barricade);
		grid[5][8].setIcon(barricade);
		grid[4][8].setIcon(barricade);
		grid[3][8].setIcon(barricade);
		grid[1][8].setIcon(barricade);

		//winning tile
		String winningURL = "/resources/winning_tile.png";
		ImageIcon winning = new ImageIcon(getClass().getResource(winningURL));
		grid[0][8].setIcon(winning);


		//making buttons we don't need invisible after creating grid, row by row, to create the actual board

		grid[0][0].setVisible(false);
		grid[0][1].setVisible(false);
		grid[0][2].setVisible(false);
		grid[0][3].setVisible(false);
		grid[0][4].setVisible(false);
		grid[0][5].setVisible(false);
		grid[0][6].setVisible(false);
		grid[0][7].setVisible(false);
		grid[0][9].setVisible(false);
		grid[0][10].setVisible(false);
		grid[0][11].setVisible(false);
		grid[0][12].setVisible(false);
		grid[0][13].setVisible(false);
		grid[0][14].setVisible(false);
		grid[0][15].setVisible(false);
		grid[0][16].setVisible(false);

		grid[2][1].setVisible(false);
		grid[2][2].setVisible(false);
		grid[2][3].setVisible(false);
		grid[2][4].setVisible(false);
		grid[2][5].setVisible(false);
		grid[2][6].setVisible(false);
		grid[2][7].setVisible(false);
		grid[2][8].setVisible(false);
		grid[2][9].setVisible(false);
		grid[2][10].setVisible(false);
		grid[2][11].setVisible(false);
		grid[2][12].setVisible(false);
		grid[2][13].setVisible(false);
		grid[2][14].setVisible(false);
		grid[2][15].setVisible(false);

		grid[4][0].setVisible(false);
		grid[4][1].setVisible(false);
		grid[4][2].setVisible(false);
		grid[4][3].setVisible(false);
		grid[4][4].setVisible(false);
		grid[4][5].setVisible(false);
		grid[4][6].setVisible(false);
		grid[4][7].setVisible(false);
		grid[4][9].setVisible(false);
		grid[4][10].setVisible(false);
		grid[4][11].setVisible(false);
		grid[4][12].setVisible(false);
		grid[4][13].setVisible(false);
		grid[4][14].setVisible(false);
		grid[4][15].setVisible(false);
		grid[4][16].setVisible(false);

		grid[5][0].setVisible(false);
		grid[5][1].setVisible(false);
		grid[5][2].setVisible(false);
		grid[5][3].setVisible(false);
		grid[5][4].setVisible(false);
		grid[5][5].setVisible(false);
		grid[5][11].setVisible(false);
		grid[5][12].setVisible(false);
		grid[5][13].setVisible(false);
		grid[5][14].setVisible(false);
		grid[5][15].setVisible(false);
		grid[5][16].setVisible(false);

		grid[6][0].setVisible(false);
		grid[6][1].setVisible(false);
		grid[6][2].setVisible(false);
		grid[6][3].setVisible(false);
		grid[6][4].setVisible(false);
		grid[6][5].setVisible(false);
		grid[6][7].setVisible(false);
		grid[6][8].setVisible(false);
		grid[6][9].setVisible(false);
		grid[6][11].setVisible(false);
		grid[6][12].setVisible(false);
		grid[6][13].setVisible(false);
		grid[6][14].setVisible(false);
		grid[6][15].setVisible(false);
		grid[6][16].setVisible(false);

		grid[7][0].setVisible(false);
		grid[7][1].setVisible(false);
		grid[7][2].setVisible(false);
		grid[7][3].setVisible(false);
		grid[7][13].setVisible(false);
		grid[7][14].setVisible(false);
		grid[7][15].setVisible(false);
		grid[7][16].setVisible(false);

		grid[8][0].setVisible(false);
		grid[8][1].setVisible(false);
		grid[8][2].setVisible(false);
		grid[8][3].setVisible(false);
		grid[8][5].setVisible(false);
		grid[8][6].setVisible(false);
		grid[8][7].setVisible(false);
		grid[8][8].setVisible(false);
		grid[8][9].setVisible(false);
		grid[8][10].setVisible(false);
		grid[8][11].setVisible(false);
		grid[8][13].setVisible(false);
		grid[8][14].setVisible(false);
		grid[8][15].setVisible(false);
		grid[8][16].setVisible(false);

		grid[9][0].setVisible(false);
		grid[9][1].setVisible(false);
		grid[9][15].setVisible(false);
		grid[9][16].setVisible(false);

		grid[10][0].setVisible(false);
		grid[10][1].setVisible(false);
		grid[10][3].setVisible(false);
		grid[10][4].setVisible(false);
		grid[10][5].setVisible(false);
		grid[10][7].setVisible(false);
		grid[10][8].setVisible(false);
		grid[10][9].setVisible(false);
		grid[10][11].setVisible(false);
		grid[10][12].setVisible(false);
		grid[10][13].setVisible(false);
		grid[10][15].setVisible(false);
		grid[10][16].setVisible(false);


		grid[12][1].setVisible(false);
		grid[12][2].setVisible(false);
		grid[12][3].setVisible(false);
		grid[12][5].setVisible(false);
		grid[12][6].setVisible(false);
		grid[12][7].setVisible(false);
		grid[12][9].setVisible(false);
		grid[12][10].setVisible(false);
		grid[12][11].setVisible(false);
		grid[12][13].setVisible(false);
		grid[12][14].setVisible(false);
		grid[12][15].setVisible(false);

		grid[14][0].setVisible(false);
		grid[14][1].setVisible(false);
		grid[14][3].setVisible(false);
		grid[14][4].setVisible(false);
		grid[14][5].setVisible(false);
		grid[14][7].setVisible(false);
		grid[14][8].setVisible(false);
		grid[14][9].setVisible(false);
		grid[14][11].setVisible(false);
		grid[14][12].setVisible(false);
		grid[14][13].setVisible(false);
		grid[14][15].setVisible(false);
		grid[14][16].setVisible(false);

		grid[15][0].setVisible(false);
		grid[15][4].setVisible(false);
		grid[15][8].setVisible(false);
		grid[15][12].setVisible(false);
		grid[15][16].setVisible(false);

		grid[16][0].setVisible(false);
		grid[16][1].setVisible(false);
		grid[16][3].setVisible(false);
		grid[16][4].setVisible(false);
		grid[16][5].setVisible(false);
		grid[16][7].setVisible(false);
		grid[16][8].setVisible(false);
		grid[16][9].setVisible(false);
		grid[16][11].setVisible(false);
		grid[16][12].setVisible(false);
		grid[16][13].setVisible(false);
		grid[16][15].setVisible(false);
		grid[16][16].setVisible(false);  



		//will probably be changed later, but this is the top panel that will have the name of the displays and
		//the settings options probably
		String logoURL = "/resources/logo.png";
		ImageIcon logo = new ImageIcon(getClass().getResource(logoURL));
		JLabel malefiz = new JLabel();
		malefiz.setIcon(logo);
		topPanel.add(malefiz);
		topPanel.add(menubar);
		Color brown = new Color(47, 29, 16);
		topPanel.setBackground(brown);
		

		//this sets the overall look of the pane by setting the dimensions and the layout,
		//and the packing it all together
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(topPanel, BorderLayout.NORTH);
		getContentPane().add(bottomPanel, BorderLayout.SOUTH);
		bottomPanel.setPreferredSize(new Dimension(500, 500));
		pack();

		//we definitely want to be able to see and close the plane
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

	}
	
	
	public void resetBoard() {
		
		//pretty much the same as before except we don't need to recreate the top panel
		bottomPanel.removeAll();
		for (int column = 0; column < 17; column ++)
		{
			for (int row = 0; row < 17; row ++)
			{
				//set the style and size and add action listener
				grid[column][row] = new JButton();
				grid[column][row].setIcon(icon);
				grid[column][row].setSize(new Dimension(400, 400));
				grid[column][row].setOpaque(true); 
				grid[column][row].setVisible(true);
				grid[column][row].setBorderPainted(false);
				grid[column][row].setEnabled(true);
				//grid[column][row].addActionListener(this);

				//add the grid to the bottom panel
				bottomPanel.add(grid [column][row]);
			}
		}

		//making the default player and barricade spaces
		//red
		String redURL = "/resources/red_tile.png";
		ImageIcon red = new ImageIcon(getClass().getResource(redURL));
		grid[14][2].setIcon(red);
		grid[15][1].setIcon(red);
		grid[15][2].setIcon(red);
		grid[15][3].setIcon(red);
		grid[16][2].setIcon(red);

		//blue
		String blueURL = "/resources/blue_tile.png";
		ImageIcon blue = new ImageIcon(getClass().getResource(blueURL));
		grid[14][6].setIcon(blue);
		grid[15][5].setIcon(blue);
		grid[15][6].setIcon(blue);
		grid[15][7].setIcon(blue);
		grid[16][6].setIcon(blue);

		//green
		String greenURL = "/resources/green_tile.png";
		ImageIcon green = new ImageIcon(getClass().getResource(greenURL));
		grid[14][10].setIcon(green);
		grid[15][9].setIcon(green);
		grid[15][10].setIcon(green);
		grid[15][11].setIcon(green);
		grid[16][10].setIcon(green);

		//yellow
		String yellowURL = "/resources/yellow_tile.png";
		ImageIcon yellow = new ImageIcon(getClass().getResource(yellowURL));
		grid[14][14].setIcon(yellow);
		grid[15][13].setIcon(yellow);
		grid[15][14].setIcon(yellow);
		grid[15][15].setIcon(yellow);
		grid[16][14].setIcon(yellow);

		//barricades
		String barricadeURL = "/resources/barricade.png";
		ImageIcon barricade = new ImageIcon(getClass().getResource(barricadeURL));
		grid[11][0].setIcon(barricade);
		grid[11][4].setIcon(barricade);
		grid[11][8].setIcon(barricade);
		grid[11][12].setIcon(barricade);
		grid[11][16].setIcon(barricade);
		grid[7][6].setIcon(barricade);
		grid[7][10].setIcon(barricade);
		grid[5][8].setIcon(barricade);
		grid[4][8].setIcon(barricade);
		grid[3][8].setIcon(barricade);
		grid[1][8].setIcon(barricade);

		//winning tile
		String winningURL = "/resources/winning_tile.png";
		ImageIcon winning = new ImageIcon(getClass().getResource(winningURL));
		grid[0][8].setIcon(winning);


		//making buttons we don't need invisible after creating grid, row by row, to create the actual board

		grid[0][0].setVisible(false);
		grid[0][1].setVisible(false);
		grid[0][2].setVisible(false);
		grid[0][3].setVisible(false);
		grid[0][4].setVisible(false);
		grid[0][5].setVisible(false);
		grid[0][6].setVisible(false);
		grid[0][7].setVisible(false);
		grid[0][9].setVisible(false);
		grid[0][10].setVisible(false);
		grid[0][11].setVisible(false);
		grid[0][12].setVisible(false);
		grid[0][13].setVisible(false);
		grid[0][14].setVisible(false);
		grid[0][15].setVisible(false);
		grid[0][16].setVisible(false);

		grid[2][1].setVisible(false);
		grid[2][2].setVisible(false);
		grid[2][3].setVisible(false);
		grid[2][4].setVisible(false);
		grid[2][5].setVisible(false);
		grid[2][6].setVisible(false);
		grid[2][7].setVisible(false);
		grid[2][8].setVisible(false);
		grid[2][9].setVisible(false);
		grid[2][10].setVisible(false);
		grid[2][11].setVisible(false);
		grid[2][12].setVisible(false);
		grid[2][13].setVisible(false);
		grid[2][14].setVisible(false);
		grid[2][15].setVisible(false);

		grid[4][0].setVisible(false);
		grid[4][1].setVisible(false);
		grid[4][2].setVisible(false);
		grid[4][3].setVisible(false);
		grid[4][4].setVisible(false);
		grid[4][5].setVisible(false);
		grid[4][6].setVisible(false);
		grid[4][7].setVisible(false);
		grid[4][9].setVisible(false);
		grid[4][10].setVisible(false);
		grid[4][11].setVisible(false);
		grid[4][12].setVisible(false);
		grid[4][13].setVisible(false);
		grid[4][14].setVisible(false);
		grid[4][15].setVisible(false);
		grid[4][16].setVisible(false);

		grid[5][0].setVisible(false);
		grid[5][1].setVisible(false);
		grid[5][2].setVisible(false);
		grid[5][3].setVisible(false);
		grid[5][4].setVisible(false);
		grid[5][5].setVisible(false);
		grid[5][11].setVisible(false);
		grid[5][12].setVisible(false);
		grid[5][13].setVisible(false);
		grid[5][14].setVisible(false);
		grid[5][15].setVisible(false);
		grid[5][16].setVisible(false);

		grid[6][0].setVisible(false);
		grid[6][1].setVisible(false);
		grid[6][2].setVisible(false);
		grid[6][3].setVisible(false);
		grid[6][4].setVisible(false);
		grid[6][5].setVisible(false);
		grid[6][7].setVisible(false);
		grid[6][8].setVisible(false);
		grid[6][9].setVisible(false);
		grid[6][11].setVisible(false);
		grid[6][12].setVisible(false);
		grid[6][13].setVisible(false);
		grid[6][14].setVisible(false);
		grid[6][15].setVisible(false);
		grid[6][16].setVisible(false);

		grid[7][0].setVisible(false);
		grid[7][1].setVisible(false);
		grid[7][2].setVisible(false);
		grid[7][3].setVisible(false);
		grid[7][13].setVisible(false);
		grid[7][14].setVisible(false);
		grid[7][15].setVisible(false);
		grid[7][16].setVisible(false);

		grid[8][0].setVisible(false);
		grid[8][1].setVisible(false);
		grid[8][2].setVisible(false);
		grid[8][3].setVisible(false);
		grid[8][5].setVisible(false);
		grid[8][6].setVisible(false);
		grid[8][7].setVisible(false);
		grid[8][8].setVisible(false);
		grid[8][9].setVisible(false);
		grid[8][10].setVisible(false);
		grid[8][11].setVisible(false);
		grid[8][13].setVisible(false);
		grid[8][14].setVisible(false);
		grid[8][15].setVisible(false);
		grid[8][16].setVisible(false);

		grid[9][0].setVisible(false);
		grid[9][1].setVisible(false);
		grid[9][15].setVisible(false);
		grid[9][16].setVisible(false);

		grid[10][0].setVisible(false);
		grid[10][1].setVisible(false);
		grid[10][3].setVisible(false);
		grid[10][4].setVisible(false);
		grid[10][5].setVisible(false);
		grid[10][7].setVisible(false);
		grid[10][8].setVisible(false);
		grid[10][9].setVisible(false);
		grid[10][11].setVisible(false);
		grid[10][12].setVisible(false);
		grid[10][13].setVisible(false);
		grid[10][15].setVisible(false);
		grid[10][16].setVisible(false);


		grid[12][1].setVisible(false);
		grid[12][2].setVisible(false);
		grid[12][3].setVisible(false);
		grid[12][5].setVisible(false);
		grid[12][6].setVisible(false);
		grid[12][7].setVisible(false);
		grid[12][9].setVisible(false);
		grid[12][10].setVisible(false);
		grid[12][11].setVisible(false);
		grid[12][13].setVisible(false);
		grid[12][14].setVisible(false);
		grid[12][15].setVisible(false);

		grid[14][0].setVisible(false);
		grid[14][1].setVisible(false);
		grid[14][3].setVisible(false);
		grid[14][4].setVisible(false);
		grid[14][5].setVisible(false);
		grid[14][7].setVisible(false);
		grid[14][8].setVisible(false);
		grid[14][9].setVisible(false);
		grid[14][11].setVisible(false);
		grid[14][12].setVisible(false);
		grid[14][13].setVisible(false);
		grid[14][15].setVisible(false);
		grid[14][16].setVisible(false);

		grid[15][0].setVisible(false);
		grid[15][4].setVisible(false);
		grid[15][8].setVisible(false);
		grid[15][12].setVisible(false);
		grid[15][16].setVisible(false);

		grid[16][0].setVisible(false);
		grid[16][1].setVisible(false);
		grid[16][3].setVisible(false);
		grid[16][4].setVisible(false);
		grid[16][5].setVisible(false);
		grid[16][7].setVisible(false);
		grid[16][8].setVisible(false);
		grid[16][9].setVisible(false);
		grid[16][11].setVisible(false);
		grid[16][12].setVisible(false);
		grid[16][13].setVisible(false);
		grid[16][15].setVisible(false);
		grid[16][16].setVisible(false);
		
		getContentPane().add(bottomPanel, BorderLayout.SOUTH);
		bottomPanel.setPreferredSize(new Dimension(500, 500));
		pack();

	}
}

