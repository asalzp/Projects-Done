
public class Piece {

}
