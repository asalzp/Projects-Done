
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**This class is responsible for providing a user-interface that allows the user to change the game's display settings.
 * 
 * @author Ryan
 *
 */
public class displaySettings extends JFrame
{
	private JButton okButton, returnButton;
	private JComboBox<String> settingComboBox;
	private JLabel displayTitleLabel, displayLabel;
	private JPanel topPanel, centerPanel, bottomPanel;
	private String displayOption;
	private String[] settings = { "Default Setting", "Colour Deficiency Friendly"};
	
	
	public displaySettings()
	{
        setTitle("Display Settings");
        
        //panels
		   topPanel = new JPanel();
       topPanel.setLayout(new FlowLayout(FlowLayout.LEADING));   
		   centerPanel = new JPanel();
       centerPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 0));   
		   bottomPanel = new JPanel();
       bottomPanel.setLayout(new FlowLayout(FlowLayout.TRAILING, 25, 20));
        
        //buttons
        okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent ev)
        	{   
        		chooseDisplayOption(settingComboBox.getSelectedItem().toString());
        		System.out.print("The display option is now: "+displayOption);
        		dispose();
        	}
        });
        returnButton = new JButton("CLOSE");
        returnButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent ev)
        	{
        		dispose();
        	}
        });
        
      //labels
        displayLabel = new JLabel("Display Setting");
        displayLabel.setFont(new java.awt.Font("Tahoma", 1, 13));
        displayTitleLabel = new JLabel("Display ");
        displayTitleLabel.setFont(new java.awt.Font("Tahoma", 1, 13));
        
        //combo box
        settingComboBox = new JComboBox<String>(settings);
        settingComboBox.setSelectedIndex(0);//select the first item as the selected one when the frame becomes visible; would ideally have the user's current display setting. 
          
        //adding components to panels
        topPanel.add(displayTitleLabel);
        
        centerPanel.add(displayLabel);
        centerPanel.add(settingComboBox);
        
        bottomPanel.add(okButton);
        bottomPanel.add(returnButton);
        
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(topPanel, BorderLayout.NORTH);//add top panel to borderlayout
        getContentPane().add(centerPanel, BorderLayout.CENTER);//add center/main panel to borderlayout
        getContentPane().add(bottomPanel, BorderLayout.SOUTH);//add bottom panel to borderlayout
        
        //Frame's final preparation
        setSize(new Dimension(500, 175));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
//        setLocationRelativeTo(null);
        setVisible(true);
//        pack();
	}
	
	/**
	 * Sets the given String as the display setting.
	 * 
	 * @param option
	 */
	private void chooseDisplayOption(String option)
	{
		displayOption = option;
	}
	
	public static void main (String args[])
	{
		new displaySettings();
	}
}


